*************************************************************
*	Project: Wordcloud Generator                        *
*	Author:  Jolita Budriene G00387921                  *
*	Course:  H. Dip in Software Development             *
*************************************************************

I used Java 17.0.1
-------------------
Project Description
-------------------
This program generates a wordcloud image from a given input file or URL,
and settings for wordcloud drawing.

The project is split into two parts.
The Menu, Parser and Runner classes manage input, option selection and
retrieving the word data from the provided file or URL

The ie.gmit.dip.wordcloud package contains various interfaces and classes
that are used by the primary Wordcloud class in order to perform the generation
of the wordcloud image.

The wordcloud package and Wordcloud class works by taking in three objects of
classes implementing the WordcloudSizer, WordcloudStyler and WordcloudArranger
interfaces. Using these generic interfaces, the Wordcloud class draws the
wordcloud image, based on the specific implementations of the interfaces.
The donus of the interfaces is that they can be mixed and matched, while also
be used to easily add more variety by another developer.

The WordcloudSizer interface determines the size of words in a wordcloud,
which can be set to be the same for all words (SizerStatic), based on
their occurrence (SizerOccurrenceLinear), or other options.

The WordcloudStyler interface determines the style of words in a wordcloud,
which can be set to be the same for all words (StylerStatic) or
randomly selected (StylerRandom).

The WordcloudArranger interface determines the locations of words in a wordcloud,
which can be set to be a single column (ArrangerSimpleVertical) or randomly
placed within the image (ArrangerRandom).

The Parser class in the base package contains static helper methods to load a
file or URL, take the contents and generate a Map of words to occurrences,
and sort the occurrence Map to give words from most to least occurring.

The Menu class manages input/output and program flow, while the Runner class
contains the main starting method of the program.

-------------------
HOW TO USE:
-------------------
1) run the program using `java -cp ./wcloud.jar ie.gmit.dip.Runner`
2) follow the instructions given on the screen to select the filename and
wordcloud options, and to generate the wordcloud.