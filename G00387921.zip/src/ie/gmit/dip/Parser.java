package ie.gmit.dip;

import java.io.BufferedReader;
import java.io.FileReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * This is a utility class with functions for loading words from either a file or an URL
 */
public class Parser {

    /**
     * This is the location of the file that contains all the words to be
     * filtered out of a wordcloud.
     */
    static final String FILTER_PATH = "./ignorewords.txt";

    /**
     * This is the overall method that takes a given path (filename or URL)
     * and returns a Map of the words mapped to the occurrences within said
     * filename or URL.
     * Running Time: O(n)
     * (n from file/webpage size)
     * @param path The filename or URL to read and process.
     * @param isURL false if pointing to a file, true if pointing to URL.
     * @return A Map from words to occurrences of words.
     * @throws Exception FileNotFound or HTTP error.
     */
    public static Map<String, Integer> getMap(String path, boolean isURL) throws Exception {

        ArrayList<String> words = new ArrayList<>();

        String contents;
        if (isURL) {
            contents = readURL(path);
        } else {
            contents = readFile(path);
        }

        // Split into processable list, remove blank
        for (String next : contents.split("\\s")) {
            if (!next.isEmpty()){
                words.add(next);
            }
        }

        // hardcode filter for now, maybe enable config later
        HashSet<String> filter = new HashSet<>();
        BufferedReader filterReader = new BufferedReader(new FileReader(FILTER_PATH));
        String nextFilter;
        while ((nextFilter = filterReader.readLine()) != null) {
            filter.add(nextFilter);
        }

        return countOccurrences(words, filter);
    }

    /**
     * Function to take the data from a webpage as a String.
     * Running Time: O(n)
     * (n from webpage size)
     * @param url The URL of the webpage.
     * @return A String of the webpage's body, with HTML tags stripped out
     * @throws Exception HTTP error.
     */
    static String readURL(String url) throws Exception {

        // code taken and adapted from: https://openjdk.java.net/groups/net/httpclient/intro.html
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .build();
        String result = client.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(HttpResponse::body)
                .join();

        // leave just the body of the webpage

        result = result.substring(result.indexOf("<body"), result.indexOf("</body>"));

        // take out all the HTML tags. code taken and adapted from:
        // https://www.tutorialspoint.com/how-to-remove-the-html-tags-from-a-given-string-in-java

        result = result.replaceAll("\\<.*?\\>", "");

        // Filter out "'s" i.e. "John's" -> "John"
        result = result.replaceAll( "'s", "");
        // Filter out punctuation and some non-word marks
        result = result.replaceAll( "[\\p{Punct}]", " ");

        return result;
    }

    /**
     * Function to take the words from a file as a String.
     * Running Time: O(n)
     * (n from file size)
     * @param filename the path of the file to read.
     * @return The file contents as a string, with punctuation filtered.
     * @throws Exception FileNotFound.
     */
    static String readFile(String filename) throws Exception {
        StringBuilder builder = new StringBuilder();
        BufferedReader reader = new BufferedReader(new FileReader(filename, StandardCharsets.UTF_8));
        String nextline;
        while ((nextline = reader.readLine()) != null) {

            // Filter out "'s" i.e. "John's" -> "John"
            nextline = nextline.replaceAll( "'s", "");
            // Filter out punctuation and some non-word marks
            nextline = nextline.replaceAll( "[\\p{Punct}]", " ");
            builder.append(nextline).append("\n");
        }
        return builder.toString();
    }

    /**
     * Function that takes a List of Strings and a Set of Strings as a filter,
     * and returns a Map of how many times a particular string was in the list,
     * excluding the Strings that were in the filter.
     * Uses a HashMap internally for efficiency.
     * Running Time: O(n)
     * @param words The Strings to be counted, split up into individual occurrences.
     * @param filter A Set of Strings to be filtered out of the occurrences.
     * @return A Map of Strings to the occurrences of them in the given list.
     */
    static Map<String, Integer> countOccurrences(List<String> words, Set<String> filter) {

        HashMap<String, Integer> occurrences = new HashMap<>();

        for (String word : words) {
            // words at the start of a sentence might not get counted with ones later in a sentence
            // so I will take all words as all lowercase.
            word = word.toLowerCase(Locale.ROOT);
            if (!filter.contains(word)) {
                Integer prev = occurrences.getOrDefault(word, 0);
                occurrences.put(word, prev + 1);
            }
        }

        return occurrences;
    }

    /**
     * Utility class that reads a map for Strings to Integers,
     * and returns a List of the key Strings, sorted from highest
     * value to lowest.
     * Adapted from:
     * https://stackoverflow.com/questions/109383/sort-a-mapkey-value-by-values
     * Running Time: O(n log(n))
     * @param map A map of Strings to Integers
     * @return The Strings of the map, sorted from the highest integer to lowest.
     */
    static List<String> keysSortedByValue(Map<String, Integer> map) {
        // Turn the map into a list of sortable entries.
        ArrayList<Map.Entry<String, Integer>> entryList = new ArrayList<>(map.entrySet());

        // Sort the list by the values, with an ordering from highest to lowest.
        entryList.sort(Map.Entry.comparingByValue((a, b) -> b - a));

        // Get the sorted keys from the entry list into a list of the keys
        ArrayList<String> keys = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : entryList) {
            keys.add(entry.getKey());
        }

        return keys;
    }
}
