package ie.gmit.dip.wordcloud;

import java.awt.*;

/**
 * This is a WordcloudStyler that styles all the words in the wordcloud in the same
 * preset style.
 */
public class StylerStatic implements WordcloudStyler {

    /**
     * The preset font to be used.
     * The font size of this object is ignored,
     * and the parameter given in setNextStyle is used instead.
     */
    Font font;

    /**
     * The preset color to be used.
     */
    Color color;

    /**
     * Instantiate the styler with a set font and color.
     * Running time: O(1)
     * @param font The font to be used.
     * @param color The color to be used.
     */
    public StylerStatic(Font font, Color color) {
        this.font = font;
        this.color = color;
    }

    /**
     * This method applies the pre-set font and color to the Graphics object, with the given font size.
     * Running time: O(1)
     * @param graphics The Graphics object which is drawing the wordcloud.
     * @param fontSize The font size of the word to be drawn.
     */
    @Override
    public void setNextStyle(Graphics graphics, Integer fontSize) {

        // the cast to float here is to differentiate between
        // public Font deriveFont(float size) - which sets the size of the font
        // and
        // public Font deriveFont(int style) - which sets the style (italic/bold/etc) of the font

        graphics.setFont(font.deriveFont((float)fontSize));
        graphics.setColor(color);

    }
}
