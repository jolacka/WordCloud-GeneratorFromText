package ie.gmit.dip.wordcloud;

import java.awt.*;

/**
 * This is a WordcloudArranger that places all the words in the exact same location.
 */
public class ArrangerStatic implements WordcloudArranger {

    int x;
    int y;

    /**
     * Instantiate the arranger with a pre-set location.
     * Running time: O(1)
     * @param x The x (left/rigth) co-ordinate.
     * @param y The y (up/down) co-ordinate.
     */
    public ArrangerStatic(int x, int y){
        this.x = x;
        this.y = y;
    }

    /**
     * Draw the given word in the pre-set location.
     * Running time: O(1)
     * @param graphics The Graphics object which is drawing the wordcloud.
     * @param word The word to be drawn.
     */
    @Override
    public void placeNextWord(Graphics graphics, String word) {

        graphics.drawString(word, x, y);

    }
}
