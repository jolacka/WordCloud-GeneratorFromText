package ie.gmit.dip.wordcloud;

/**
 * This is the interface for classes that determine the font size of the next word in a wordcloud.
 * The interface only requires the implementation of the nextFontSize method.
 * Any other functionality or necessary data for features are left to be
 * written in the implementing class.
 */
public interface WordcloudSizer {
    /**
     * Decide and return the font size to be used for the next word in the wordcloud.
     * The running time is depends on the specific implementation.
     *
     * @return The font size of the next word in the wordcloud.
     */
    public Integer nextFontSize();
}
