package ie.gmit.dip.wordcloud;

import java.awt.*;

/**
 * This is the interface for classes that determine the style of the words in a wordcloud.
 * The interface only requires the implementation of the setNextStyle method.
 * Any other functionality or necessary data for features are left to be
 * written in the implementing class.
 */
public interface WordcloudStyler {
    /**
     * Decide and apply the style to be used by the next word in the wordcloud.
     * This method is expected to call Graphics operations such as setFont and setColor.
     * The running time is depends on the specific implementation.
     *
     * @param graphics The Graphics object which is drawing the wordcloud.
     * @param fontSize The font size of the word to be drawn.
     */
    public void setNextStyle(Graphics graphics, Integer fontSize);
}
