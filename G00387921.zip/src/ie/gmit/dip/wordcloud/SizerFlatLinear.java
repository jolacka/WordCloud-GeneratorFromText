package ie.gmit.dip.wordcloud;


import java.util.AbstractList;

/**
 * This is a WordcloudSizer that sizes words in a wordcloud from large
 * to small, in a linear calculation, with no regards for the relative
 * occurrence of words.
 */
public class SizerFlatLinear implements WordcloudSizer {

    Integer numberOfWords;
    Integer max;
    Integer min;
    Integer currentWord;

    /**
     * Instantiates the sizer, performing the setup needed so that
     * the sizing is done correctly
     * Running Time: O(1)
     * @param numberOfWords The number of words in the wordcloud.
     * @param max The maximum font size (and the size of the first word)
     * @param min The minimum font size (and the size of the last word)
     */
    public SizerFlatLinear(Integer numberOfWords, Integer max, Integer min){
        this.numberOfWords = numberOfWords;
        this.max = max;
        this.min = min;
        currentWord = 0;
    }

    /**
     * Returns the font size of the current word, and updates values
     * so that the correct size is given for the next word.
     * Running Time: O(1)
     * @return The font size of the next word in the wordcloud.
     */
    @Override
    public Integer nextFontSize() {

        Integer fontSize = max - (((max - min) / (numberOfWords - 1)) * currentWord);
        currentWord++;
        return fontSize;
    }
}
