package ie.gmit.dip.wordcloud;


/**
 * This is a WordcloudSizer that sizes all the words in the wordcloud in the same
 * preset font size.
 */
public class SizerStatic implements WordcloudSizer {

    /**
     * The preset font size.
     */
    Integer size;

    /**
     * Instantiate the sizer with a set font size.
     * Running time: O(1)
     * @param size The font size to be used.
     */
    public SizerStatic(Integer size){
        this.size = size;
    }

    /**
     * Return the pre-set value for the font size.
     * Running time: O(1)
     * @return The font size to be used.
     */
    @Override
    public Integer nextFontSize() {
        return size;
    }
}
