package ie.gmit.dip.wordcloud;

import java.awt.*;

/**
 * This is the interface for classes that decide how a wordcloud is arranged.
 * The interface only requires the implementation of the placeNextWord method.
 * Any other functionality or necessary data for features are left to be
 * written in the implementing class.
 */
public interface WordcloudArranger {
    /**
     * Place the next word into the wordcloud image.
     * This method is expected to perform the drawString operation on the given Graphics object.
     * The running time depends on the specific implementation.
     *
     * @param graphics The Graphics object which is drawing the wordcloud.
     * @param word The word to be drawn.
     */
    public void placeNextWord(Graphics graphics, String word);
}
