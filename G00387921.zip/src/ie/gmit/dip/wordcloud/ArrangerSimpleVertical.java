package ie.gmit.dip.wordcloud;

import java.awt.*;

/**
 * This is a WordcloudArranger that places all the words in a column, going downwards.
 * Unlike the co-ordinate parameters of drawString, which represent the bottom-left
 * corner of the word being drawn, the co-ordinates supplies to this class represent
 * the upper-left corner, in order to properly implement the vertical arrangement.
 */
public class ArrangerSimpleVertical implements WordcloudArranger {

    int x;
    int currentY;
    /**
     * This factor represents the amount that the point size of a word effects spacing
     * between words. 1 is exact to the point size, less than 1 is closer,
     * more than 1 is further.
     */
    float scaleFactor;

    /**
     * Instantiate the arranger with the starting upper-left position
     * and the ratio between the point size of words and distance between them
     * Running Time: O(1)
     * @param x The x co-ordinate of the starting position.
     * @param y The y co-ordinate of the starting position.
     * @param scaleFactor The ratio between font size and word spacing.
     */
    public ArrangerSimpleVertical(int x, int y, float scaleFactor) {
        this.x = x;
        this.currentY = y;
        this.scaleFactor = scaleFactor;
    }

    /**
     * Determines the location of the next word to be drawn, draws the word,
     * and updates the values so that words are drawn in a column.
     * Running Time: O(1)
     * @param graphics The Graphics object which is drawing the wordcloud.
     * @param word The word to be drawn.
     */
    @Override
    public void placeNextWord(Graphics graphics, String word) {

        float fontSize = graphics.getFont().getSize2D();
        graphics.drawString(word, x, currentY + (int)Math.floor(fontSize));
        currentY += fontSize * scaleFactor;

    }
}
