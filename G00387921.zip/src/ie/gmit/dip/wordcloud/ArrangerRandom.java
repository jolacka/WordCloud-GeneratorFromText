package ie.gmit.dip.wordcloud;

import java.awt.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * This is a WordcloudArranger that randomly places words throughout
 * an image, within the max/min bounds this arranger was instantiated with.
 *
 * When drawing words, the given co-ordinate refers to the bottom-left
 * corner of the word, so adjust the max/min bounds in regard to this.
 */
public class ArrangerRandom implements WordcloudArranger {

    int minX;
    int minY;
    int maxX;
    int maxY;

    /**
     * Instantiate the Arranger with bounds on where to draw within
     * the image. The bounds determine the bottom-left corner of the word.
     * Running Time: O(1)
     * @param minX The minimum X co-ordinate to draw at.
     * @param minY The minimum Y co-ordinate to draw at.
     * @param maxX The maximum X co-ordinate to draw at.
     * @param maxY The maximum Y co-ordinate to draw at.
     */
    public ArrangerRandom(int minX, int minY, int maxX, int maxY){
        this.minX = minX;
        this.minY = minY;
        this.maxX = maxX;
        this.maxY = maxY;
    }

    /**
     * Randomly place and draw the word with the given Graphics object
     * within the bounds provided to this Arranger.
     * Running Time: O(1)
     * @param graphics The Graphics object which is drawing the wordcloud.
     * @param word     The word to be drawn.
     */
    @Override
    public void placeNextWord(Graphics graphics, String word) {
        int x = ThreadLocalRandom.current().nextInt(minX, maxX + 1);
        int y = ThreadLocalRandom.current().nextInt(minY, maxY + 1);

        graphics.drawString(word, x, y);

    }
}
