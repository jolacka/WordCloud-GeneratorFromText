package ie.gmit.dip.wordcloud;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.List;

/**
 * This class takes in a sizer, styler and arranger, and uses them to arrange a given list
 * of words into a wordcloud on a given image
 */
public class Wordcloud {

    WordcloudSizer sizer;
    WordcloudStyler styler;
    WordcloudArranger arranger;
    List<String> wordlist;
    BufferedImage image;

    /**
     * Instantiate a wordcloud creator.
     * Running Time: O(1)
     * @param sizer The WordcloudSizer that determines the font size of words in the wordcloud.
     * @param styler The WordcloudStyler that determines the style of words in the wordcloud.
     * @param arranger The WordcloudArranger that determines the location of words in the wordcloud.
     * @param wordlist The List of words, sorted by order of occurrence, from most to least common.
     * @param image The BufferedImage on which the wordcloud is drawn.
     */
    public Wordcloud(WordcloudSizer sizer, WordcloudStyler styler, WordcloudArranger arranger, List<String> wordlist, BufferedImage image) {
        this.sizer = sizer;
        this.styler = styler;
        this.arranger = arranger;
        this.wordlist = wordlist;
        this.image = image;
    }

    /**
     * Perform the process of drawing the wordcloud, using the given
     * WordcloudSizer, WordcloudStyler and WordcloudArranger.
     * Running Time: O(n) * running time of given classes.
     */
    public void drawWordcloud() {
        // very basic loop for now, probably needs refinement
        Graphics2D graphics = image.createGraphics();
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics.setColor(Color.white);
        graphics.fillRect(0,0, image.getWidth(), image.getHeight());

        for (int index = 0; index < wordlist.size(); index++) {
            Integer fontsize = sizer.nextFontSize();

            styler.setNextStyle(graphics, fontsize);

            arranger.placeNextWord(graphics, wordlist.get(index));
        }

        graphics.dispose();
    }
}
