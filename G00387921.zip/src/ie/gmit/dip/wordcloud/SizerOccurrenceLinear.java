package ie.gmit.dip.wordcloud;

import java.util.List;
import java.util.Map;

/**
 * This is a WordcloudSizer that sizes the words in a wordcloud
 * according to their occurence (more precisely the ratio of the
 * word's occurrence to the occurrence of the most common word)
 */
public class SizerOccurrenceLinear implements WordcloudSizer{

    Map<String, Integer> occurrences;
    List<String> sortedWords;
    Integer maxOccurrences;
    Integer maxSize;
    Integer minSize;

    /**
     * Variable for keeping track of which word is currently being sized.
     */
    int currentWord;

    /**
     * Initialise the Sizer with the wordcloud information.
     * Running Time: O(1)
     * @param occurrences The Map of words to occurrences.
     * @param sortedWords The sorted list of words, from most to least common.
     */
    public SizerOccurrenceLinear(Map<String, Integer> occurrences, List<String> sortedWords, Integer maxSize, Integer minSize) {
        this.occurrences = occurrences;
        this.sortedWords = sortedWords;
        // Since we already have sortedWords sorted, we can just get the number
        // by checking the occurrences of the first word of the list.
        this.maxOccurrences = occurrences.get(sortedWords.get(0));
        this.maxSize = maxSize;
        this.minSize = minSize;

        currentWord = 0;
    }

    /**
     * Calculate and return the next word's font size.
     * This depends on The Wordcloud class processing words
     * in the same order as given with the sortedWords class parameter.
     * Running Time: O(1)
     * @return The font size to be used.
     */
    @Override
    public Integer nextFontSize() {
        float ratio = (float) occurrences.get(sortedWords.get(currentWord)) / (float) maxOccurrences;
        currentWord += 1;
        return Math.round(minSize + ((maxSize - minSize) * ratio));
    }
}
