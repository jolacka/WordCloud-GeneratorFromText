package ie.gmit.dip.wordcloud;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * This is a WordcloudStyler that styles all the words in the wordcloud in a
 * random style from given Font-Color pairs.
 *
 * This class has a small subclass to allow for easier pairing of Font and Color
 * objects.
 */
public class StylerRandom implements WordcloudStyler{

    /**
     * A utility subclass that pairs together a Font and a Color.
     */
    static class FontColorPair {
        public Font font;
        public Color color;

        /**
         * Pair together a Font and a Color.
         * Running Time: O(1)
         * @param font The Font to be used with the color. The size variable is ignored.
         * @param color The Color to be used with the font.
         */
        public FontColorPair(Font font, Color color) {
            this.font = font;
            this.color = color;
        }
    }

    List<FontColorPair> selection;

    /**
     * Initialise the Styler with an empty List of font color pairs.
     * Running Time: O(1)
     */
    public StylerRandom() {
        selection = new ArrayList<>();
    }

    /**
     * Add a new font-color pair to the possible font-color pairs that
     * this Styler can use.
     * Running Time: O(1)
     * @param font The Font to be used with the color. The size variable is ignored.
     * @param color The Color to be used with the font.
     */
    public void addFontColor(Font font, Color color) {
        selection.add(new FontColorPair(font, color));
    }

    /**
     * This method selects a random font-color pair, and applies it to the given Graphics
     * object, with the provided font size.
     * Running time: O(1)
     * @param graphics The Graphics object which is drawing the wordcloud.
     * @param fontSize The font size of the word to be drawn.
     */
    @Override
    public void setNextStyle(Graphics graphics, Integer fontSize) {
        int index = ThreadLocalRandom.current().nextInt(0, selection.size());
        Font font = selection.get(index).font;
        Color color = selection.get(index).color;

        // the cast to float here is to differentiate between
        // public Font deriveFont(float size) - which sets the size of the font
        // and
        // public Font deriveFont(int style) - which sets the style (italic/bold/etc) of the font

        graphics.setFont(font.deriveFont((float)fontSize));
        graphics.setColor(color);

    }
}
