package ie.gmit.dip;

/**
 * Utility class for launching the program.
 */
public class Runner {

    /**
     * Program main method, used to start the menu for the word cloud generator.
     */
    public static void main(String[] args) {

        Menu menu = new Menu();
        try {
            menu.show();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
