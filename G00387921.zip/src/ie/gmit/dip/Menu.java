package ie.gmit.dip;

import ie.gmit.dip.wordcloud.*;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Menu
{
    //Call the scanner class and declare variables
    private Scanner s = new Scanner(System.in);
    private String option;
    private boolean keepGoing = true;
    private Map<String,Integer> words;
    private List<String> sortedWords;

    //variables for wordcloud settings
    private int numWords = 25;
    private String imgName = "default.png";
    private WordcloudSizer sizer;
    private WordcloudStyler styler;
    private WordcloudArranger arranger;

    //variables for showing the menu
    private String fileURLStatus = "No Input Given";
    private String sizerStatus = "Not Yet Selected";
    private String stylerStatus = "Not Yet Selected";
    private String arrangerStatus = "Not Yet Selected";

    //show function to be called in menu
    public void show() throws Exception
    {
        while(keepGoing)
        {
            //call the printMenu and handle option
            printMenu();
            handle(option);
        }
    }

    //print out the print menu option for the user
    public void printMenu()
    {
        System.out.println("|===============================================================|");
        System.out.println("||* Word Cloud Generator - Please choose one of the following *||");
        System.out.println("|===============================================================|");
        System.out.printf("||1. Enter number of words to show (Current = %-17s||%n", String.format("%d)", numWords));
        System.out.printf("||2. Enter Image name (Current = %-30s||%n", String.format("%s)", imgName));
        System.out.printf("||3. Select file or url (%-38s||%n", String.format("%s)", fileURLStatus));
        System.out.printf("||4. Select Sizer (%-44s||%n", String.format("%s)", sizerStatus));
        System.out.printf("||5. Select Styler (%-43s||%n", String.format("%s)", stylerStatus));
        System.out.printf("||6. Select Arranger (%-41s||%n", String.format("%s)", arrangerStatus));
        System.out.println("||7. Generate Word Cloud                                       ||");
        System.out.println("||8. Quit                                                      ||");
        System.out.println("|===============================================================|");
        option = s.nextLine();

    }

    //depending on the user input execute one of the following options
    public void handle(String option) throws Exception
    {
        switch (option) {
            //Ask the user to input the new amount of words to use
            case "1" -> {

                System.out.println("Please enter the number of words you would like to be displayed: ");

                String input = s.nextLine();
                try
                {
                    int newWords = Integer.parseInt(input);
                    if (newWords <= 0)
                    {
                        throw new NumberFormatException();
                    }
                    this.numWords = newWords;
                } catch (NumberFormatException ex)
                {
                    System.out.println("Invalid input - please input a valid positive integer");
                    return;
                }

                if (words != null) {
                    sortedWords = Parser.keysSortedByValue(words);
                    if (sortedWords.size() > numWords)
                        sortedWords = sortedWords.subList(0, numWords);
                }

                System.out.println("The new number of words allowed is: " + this.numWords);
            }
            //ask the user to input the new image name
            case "2" -> {

                System.out.println("Please enter the name of the image: ");

                String newImgName = s.nextLine();
                if (newImgName.isEmpty()) {
                    System.out.println("Invalid input - please input a valid file name");
                    return;
                }

                this.imgName = newImgName;

                System.out.println("The new image name is: " + this.imgName);
            }
            //ask for file or url and parse it, then print it to an image
            case "3" -> {

                String path;
                String fileOrUrl;
                boolean url;

                System.out.println("Would you like to enter a file name or a url?");
                System.out.println("1. File");
                System.out.println("2. URL");
                fileOrUrl = s.nextLine();

                switch (fileOrUrl) {
                    case "1" -> {url = false;}
                    case "2" -> {url = true;}
                    default -> {
                        System.out.println("Invalid input - please select '1' or '2'");
                        return;
                    }
                }

                if (url) {
                    System.out.println("Please enter the URL:");
                    path = s.nextLine().toLowerCase();
                    fileURLStatus = String.format("URL: %s", path);
                    words = Parser.getMap(path, true);
                } else {
                    System.out.println("Please enter the file name:");
                    path = s.nextLine().toLowerCase();
                    fileURLStatus = String.format("File: %s", path);
                    words = Parser.getMap(path, false);
                }

                sortedWords = Parser.keysSortedByValue(words);
                if (sortedWords.size() > numWords)
                    sortedWords = sortedWords.subList(0, numWords);

            }
            //choose the sizer
            case "4" -> {

                if (words == null) {
                    System.out.println("No file name or URL given");
                    return;
                }

                String choice;

                System.out.println("Which Sizer would you like to use");
                System.out.println("1. Static (same size for all words)");
                System.out.println("2. Linear (from most to least common, does not look at occurrence)");
                System.out.println("3. Occurrence (the more common the word, the bigger the font)");
                choice = s.nextLine();

                switch (choice) {
                    case "1" -> {
                        sizer = new SizerStatic(24);
                        sizerStatus = "Static";
                    }
                    case "2" -> {
                        sizer = new SizerFlatLinear(sortedWords.size(), 48, 24);
                        sizerStatus = "Linear";
                    }
                    case "3" -> {
                        sizer = new SizerOccurrenceLinear(words, sortedWords, 48, 12);
                        sizerStatus = "Occurrence";
                    }
                    default -> {
                        System.out.println("Invalid input - please select '1', '2' or '3'");
                        return;
                    }
                }
            }
            //choose the styler
            case "5" -> {

                String choice;

                System.out.println("Which Styler would you like to use");
                System.out.println("1. Static (same style for all words)");
                System.out.println("2. Random (select a style from a set of styles randomly)");
                choice = s.nextLine();

                switch (choice) {
                    case "1" -> {
                        styler = new StylerStatic(new Font(Font.SANS_SERIF, Font.PLAIN, 1), Color.darkGray);
                        stylerStatus = "Static";
                    }
                    case "2" -> {
                        StylerRandom newstyler = new StylerRandom();
                        newstyler.addFontColor(new Font(Font.SANS_SERIF, Font.PLAIN, 1), Color.darkGray);
                        newstyler.addFontColor(new Font(Font.MONOSPACED, Font.PLAIN, 1), Color.orange);
                        newstyler.addFontColor(new Font(Font.SERIF, Font.PLAIN, 1), Color.blue);
                        newstyler.addFontColor(new Font(Font.SANS_SERIF, Font.PLAIN, 1), Color.red);
                        styler = newstyler;
                        stylerStatus = "Random";
                    }
                    default -> {
                        System.out.println("Invalid input - please select '1', '2' or '3'");
                        return;
                    }
                }
            }
            //choose the arranger
            case "6" -> {

                String choice;

                System.out.println("Which Arranger would you like to use");
                System.out.println("1. Vertical (place words in one column)");
                System.out.println("2. Random (place words around the image randomly)");
                choice = s.nextLine();

                switch (choice) {
                    case "1" -> {
                        arranger = new ArrangerSimpleVertical(20, 20, 0.95F);
                        arrangerStatus = "Vertical";
                    }
                    case "2" -> {
                        arranger = new ArrangerRandom(20, 30, 700, 580);
                        arrangerStatus = "Random";
                    }
                    default -> {
                        System.out.println("Invalid input - please select '1', or '2'");
                        return;
                    }
                }
            }
            //generate the file
            case "7" -> {
                if (words == null) {
                    System.out.println("No file name or URL given");
                    return;
                }
                if (sizer == null) {
                    System.out.println("No Sizer selected");
                    return;
                }
                if (styler == null) {
                    System.out.println("No Styler selected");
                    return;
                }
                if (arranger == null) {
                    System.out.println("No Arranger selected");
                    return;
                }

                BufferedImage image = new BufferedImage(800, 600, BufferedImage.TYPE_4BYTE_ABGR);
                Wordcloud wordcloud = new Wordcloud(sizer, styler, arranger, sortedWords, image);
                wordcloud.drawWordcloud();
                ImageIO.write(image, "png", new File(imgName));
                System.out.println("Word Cloud image generated!");
            }
            //exit the program
            case "8" -> {
                System.out.println("You have exited the program!");
                keepGoing = false;
            }
        }
    }

}

